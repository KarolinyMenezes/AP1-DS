﻿using Listas;

List<animal> animais = new List<animal>();

animais.Add(new Cachorro());
animais.Add(new Gato());
animais.Add(new Vaca());

foreach (animal animal in animais)
{
    animal.EmitirSom();
}