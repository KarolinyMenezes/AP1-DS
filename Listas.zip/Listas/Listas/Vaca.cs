﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas
{
    internal class Vaca : animal
    {
        public override void EmitirSom()
        {
            Console.WriteLine("Muuuu");
        }
    }
}
