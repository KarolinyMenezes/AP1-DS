﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas
{
    internal class Cachorro : animal
    {
        public override void EmitirSom()
        {
            Console.WriteLine("Au Au");
        }
    }
}
