﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas
{
    internal class animal
    {
        public virtual void EmitirSom()
        {
            Console.WriteLine("Som genérico");
        }
    }
}
